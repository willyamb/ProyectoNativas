package com.example.distrimascotapp.models;

import java.util.List;

public class ResponseWeb {
    private List<Object> result;

    public List<Object> getResult() {
        return result;
    }

    public void setResult(List<Object> result) {
        this.result = result;
    }
}
