package com.example.distrimascotapp.models;

public class Table {
    private int id;
    private String name_table;
    private int id_status;

    // Getters y setters
    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getName() {
        return name_table;
    }

    public void setName(String name_table) {
        this.name_table = name_table;
    }

    public int getId_status() {
        return id_status;
    }

    public void setId_status(int id_status) {
        this.id_status = id_status;
    }
}
