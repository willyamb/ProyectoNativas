package com.example.distrimascotapp.models;

public class Error {
    private String msg;

    public String getMsg() {
        return msg;
    }
}
